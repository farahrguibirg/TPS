package TP2;

import java.util.Scanner;
public class MainArticle {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("donner la reference");
		String reference =sc.next();
		System.out.println("donner la designation");
		String designation =sc.next();
		System.out.println("donner le prix HT");
		int prixht=sc.nextInt();
		System.out.println("donner le taux tva pour tous les articles");
		double tauxtva=sc.nextDouble();
		Article article=new Article(reference,designation,prixht,tauxtva);
		article.afficher();

	}

}
