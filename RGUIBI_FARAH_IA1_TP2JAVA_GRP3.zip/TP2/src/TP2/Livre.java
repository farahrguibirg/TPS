package TP2;

public class Livre {
 private String Titre,Auteur;
 private double prix;
 
 public Livre(String titre,String auteur,double prix){
	 this.Titre=titre;
	 this.Auteur=auteur;
	 this.prix=prix;
 }
	public String gettitre() {
		return Titre;}
	public String getauteur() {
		return Auteur;}
	public double getprix() {
		return prix;}
	public void settitre(String titre) {
		this.Titre=titre;}
	public void setauteur(String auteur) {
		this.Auteur=auteur;}
	public void setprix(double prix) {
		if(prix>=0) {
			this.prix=prix;
		}else {
			System.out.println("erreur");
		}}
	public void afficher() {
		System.out.println("le titre est " + Titre);
		System.out.println("l'auteur est " + Auteur);
		System.out.println("le prix est " + prix);
	}}
