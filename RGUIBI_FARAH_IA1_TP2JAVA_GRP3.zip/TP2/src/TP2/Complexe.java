package TP2;

public class Complexe {
	private int reel,imaginaire;
	
	public Complexe() {
		this.reel=0;
		this.imaginaire=0;}
	public Complexe(int reel,int imaginaire) {
		this.reel=reel;
		this.imaginaire=imaginaire;}
	public int getreel() {
		return reel;}
	public int getimaginaire() {
		return imaginaire;}
	public void setreel(int reel) {
		this.reel=reel;}
	public void setimaginaire(int imaginaire) {
		this.imaginaire=imaginaire;}
	public Complexe plus(Complexe A) {
		int re=this.reel+A.reel;
		int im =this.imaginaire+A.imaginaire;
		return new Complexe(re,im);}
	public Complexe Moins(Complexe A) {
	    int re = this.reel - A.reel;
	    int im = this.imaginaire - A.imaginaire;
	    return new Complexe(re, im);}
	public void afficher() {
		if(reel >= 0) {
			System.out.println(reel +" +"+ imaginaire +"i");
		}else {
			System.out.println(reel +" - " + (-imaginaire) +"i");
		}
	}}
