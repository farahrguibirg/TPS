package TP2;

import java.util.Scanner;

public class MainPoint {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("entrer la valeur de x");
		int x=sc.nextInt();
		
		System.out.println("entrer la valeur de y");
		int y=sc.nextInt();
		Point p=new Point(x,y);
		System.out.println("La norme du point est : " + p.Norme());
	}

}
