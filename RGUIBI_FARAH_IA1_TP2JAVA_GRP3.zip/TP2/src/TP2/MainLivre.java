package TP2;

import java.util.Scanner;
public class MainLivre {

	public static void main (String []args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("donner le titre de livre");
		String titre=sc.next();
		System.out.println("donner l'auteur de livre ");
		String auteur=sc.next();
		System.out.println("donner le prix de livre");
		double prix=sc.nextDouble();
		Livre livre=new Livre(titre,auteur,prix);
		livre.afficher();
	}

}
