package TP2;

import java.util.Scanner;

public class MainRectangle {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("entrer la valeur de largeur");
		double largeur=sc.nextDouble();
		System.out.println("entrer la valeur de longueur");
		double longueur=sc.nextDouble();
		Rectangle R=new Rectangle(largeur,longueur);
		R.AfficherRectangle();

	}

}
