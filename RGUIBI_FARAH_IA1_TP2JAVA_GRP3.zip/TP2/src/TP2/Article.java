package TP2;

public class Article {
	
	private String reference;
	private String designation;
	private double prixHT;
	private static double tauxTVA; 

	public Article() {
	    this.reference = "";
	    this.designation = "";
	    this.prixHT = 0.0;}
	public Article(String reference, String designation, double prixHT, double tauxTVA) {
	    this.reference = reference;
	    this.designation = designation;
	    this.prixHT = prixHT;
	    Article.tauxTVA = tauxTVA;}

	public Article(String reference, String designation) {
	    this.reference = reference;
	    this.designation = designation;
	    this.prixHT = 0.0;}

	public Article(Article A) {
	    this.reference = A.reference;
	    this.designation = A.designation;
	    this.prixHT = A.prixHT;}
	public double  calculprixttc() {
		return prixHT+(prixHT*tauxTVA/100);}
	public void afficher() {
		System.out.println("la reference est = "+ reference);
		System.out.println("la designation est = "+ designation);
		System.out.println("le prixHT est = "+ prixHT);
		System.out.println("le prixttc est = "+ calculprixttc());}}
