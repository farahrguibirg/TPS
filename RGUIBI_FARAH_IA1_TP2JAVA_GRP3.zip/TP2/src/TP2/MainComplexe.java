package TP2;

import java.util.Scanner;

public class MainComplexe {
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Entrez la partie réelle du premier nombre : ");
	    int re1 = sc.nextInt();
	    System.out.println("Entrez la partie imaginaire du premier nombre : ");
	    int im1 = sc.nextInt();
	    Complexe z1 = new Complexe(re1, im1);

	    System.out.println("Entrez la partie réelle du deuxième nombre : ");
	    int re2 = sc.nextInt();
	    System.out.println("Entrez la partie imaginaire du deuxième nombre : ");
	    int im2 = sc.nextInt();
	    Complexe z2 = new Complexe(re2, im2);

	    System.out.print("Premier nombre complexe : ");
	    z1.afficher();
	    System.out.print("Deuxième nombre complexe : ");
	    z2.afficher();
	    
	    Complexe somme =z1.plus(z2);
	    System.out.println("Somme :");
	    somme.afficher();
	    
	    Complexe moins =z1.Moins(z2);
	    System.out.println("moins :");
	    moins.afficher();
}}
