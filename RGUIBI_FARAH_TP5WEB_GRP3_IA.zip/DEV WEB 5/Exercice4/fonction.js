const numbers = [1, 2, 3, 4, 5];
const fonction = () => numbers.map(n => n * 2);
console.log(fonction()); 