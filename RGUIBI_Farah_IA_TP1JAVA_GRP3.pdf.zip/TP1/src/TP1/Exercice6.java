package TP1;
import java.util.Scanner;
public class Exercice6{
	public static String reverse(String chaine) {
		String reverse="";
		for(int i=chaine.length()-1;i>=0;i--){
			reverse+=chaine.charAt(i);
		}return reverse;
		
	}
	public static void main(String[]args) {
		String chaine;
		Scanner sc=new Scanner(System.in);
		System.out.println("Entere la chaine a renverser");
		chaine=sc.next();
		String r=reverse(chaine);
		System.out.println("l'inverse est = " + r);
		
	}
}