package TP1;
import java.util.Scanner;
public class Exercice5{
	public static String remplacerchaine(String chaine,int index ,char ch ) {
		if(index >= 0 && index < chaine.length()) {
			StringBuilder b= new StringBuilder(chaine);
			b.setCharAt(index, ch);
			return b.toString();
		}else {
			System.out.println("Error");
			return chaine;
		}
	}
	public static void main (String[]args) {
		String chaine ; char ch;
		int index;
		Scanner sc=new Scanner(System.in);
		System.out.println("Entrer la chaine de caractere");
		chaine=sc.next();
		System.out.println("Entrer l'index a remplacer");
		index=sc.nextInt();
		System.out.println("Entrer le caractere");
		ch=sc.next().charAt(0);
		String a=remplacerchaine(chaine,index,ch);
		System.out.println("la nouvelle chaine est = "+a);
	}
}