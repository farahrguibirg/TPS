package TP1;
public class BonjourENIAD{
public static void main (String[]args){
System.out.println("Bonjour Eniad!");
}
}