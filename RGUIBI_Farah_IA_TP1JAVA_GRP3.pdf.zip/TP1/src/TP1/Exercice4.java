package TP1;
import java.util.Scanner;
public class Exercice4{
	public static void remplacer(String chaine, int index) {
	  if( index >= 0 && index < chaine.length()) {
			char c = chaine.charAt(index);
            System.out.println("Le caractère à l'index " + index + " est : '" + c + "'");
		}else {
			System.out.println("Invalide");
		}
		
	}
public static void main(String[]args) {
	String chaine; int index;
	Scanner sc= new Scanner(System.in);
	System.out.println("Ecrire la chaine de caractere");
	chaine = sc.next();
	System.out.println("Entrer l'index a afficher");
	index=sc.nextInt();
	remplacer(chaine,index);
}
}