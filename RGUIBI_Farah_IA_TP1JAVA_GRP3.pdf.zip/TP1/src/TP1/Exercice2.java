package TP1;
import java.util.Scanner;
public class Exercice2 {
	public static void max(int x,int y,int z) {
		int max =x;
		if(max<y) {
			max=y;
		}if(max<z) {
			max=z;
		}
		System.out.println("la maximum est "+ max);
	}
public static void main(String[]args) {
	int x,y,z;
	Scanner sc=new Scanner(System.in);
	System.out.println("Entrer la valeur de x");
	x=sc.nextInt();
	System.out.println("Entrer la valeur de y");
	y=sc.nextInt();
	System.out.println("Entrer la valeur de z");
	z=sc.nextInt();
	max(x,y,z);
}
}
