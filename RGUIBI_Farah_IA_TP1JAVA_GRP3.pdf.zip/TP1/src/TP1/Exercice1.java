package TP1;
import java.util.Scanner;
public class Exercice1 {
	public static void echange(int n,int m) {
		int a=n;
		n=m;
		m=a;
		System.out.println("les valeurs apres l'echange sont n =" + n + "et m = " + m );
	}
public static void main(String[]args) {
	int n,m;
	Scanner sc = new Scanner(System.in);
	System.out.println("Entrer le premiere valeur");
	n=sc.nextInt();
	System.out.println("Entrer la deuxieme valeur");
	m=sc.nextInt();
	System.out.println("les valeurs avant l'echange sont n =" + n + " et m = " +m);
	echange(n,m);
}
}
