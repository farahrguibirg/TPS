package TP1;
import java.util.Scanner;

public class Exercice3 {
	public static int fact(int a) {
		int b=1;
		if(a==0 || a==1) {
			return 1;
		}else {
			for(int i=1;i<=a;i++) {
				b=b*i;
			}
		}return b;
	}
public static void main ( String[]args) {
	int a;
	Scanner sc= new Scanner(System.in);
	System.out.println("entrer un nombre");
	a=sc.nextInt();
	int b=fact(a);
	System.out.println("la factoriel est = " + b);
}
}
