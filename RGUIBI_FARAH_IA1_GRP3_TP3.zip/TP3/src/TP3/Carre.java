package TP3;


class Carre extends Rectangle {
    public Carre() {
        super();
        this.nom = "carré";
        this.largeur = this.longueur; 
    }
}